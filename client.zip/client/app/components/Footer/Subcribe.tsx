'use client';
import React, { useState } from 'react';

type Props = {};

const Subcribe = ({ }: Props) => {
  const [email, setEmail] = useState('');
  return <div>Subcribe</div>;
};

export default Subcribe;
